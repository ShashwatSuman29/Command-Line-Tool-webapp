DevHelper CLI Installer
=====================

Version: 1.5.0
Release Date: 2025-04-30

INSTALLATION INSTRUCTIONS:
1. Run the 'devhelper-cli-installer.bat' file with administrator privileges
2. Follow the on-screen instructions
3. After installation, restart your terminal/command prompt
4. Verify installation by typing 'devhelper --version'

SYSTEM REQUIREMENTS:
- Windows 10 or higher
- Node.js v14 or higher
- 500MB free disk space

For more information and documentation, visit:
https://devhelper-cli.example.com

For support, contact:
support@devhelper-cli.example.com
